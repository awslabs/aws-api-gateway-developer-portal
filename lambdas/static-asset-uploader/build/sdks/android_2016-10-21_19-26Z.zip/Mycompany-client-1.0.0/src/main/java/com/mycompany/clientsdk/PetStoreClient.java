/*
 * Copyright 2010-2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 *  http://aws.amazon.com/apache2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */

package com.mycompany.clientsdk;

import java.util.*;

import com.mycompany.clientsdk.model.Empty;


@com.amazonaws.mobileconnectors.apigateway.annotation.Service(endpoint = "https://dhz2hj6zgh.execute-api.us-east-1.amazonaws.com/prod")
public interface PetStoreClient {


    /**
     * A generic invoker to invoke any API Gateway endpoint.
     * @param request
     * @return ApiResponse
     */
    com.amazonaws.mobileconnectors.apigateway.ApiResponse execute(com.amazonaws.mobileconnectors.apigateway.ApiRequest request);
    
    /**
     * 
     * 
     * @return void
     */
    @com.amazonaws.mobileconnectors.apigateway.annotation.Operation(path = "/", method = "GET")
    void rootGet();
    
    /**
     * 
     * 
     * @return Empty
     */
    @com.amazonaws.mobileconnectors.apigateway.annotation.Operation(path = "/", method = "POST")
    Empty rootPost();
    
    /**
     * 
     * 
     * @return Empty
     */
    @com.amazonaws.mobileconnectors.apigateway.annotation.Operation(path = "/", method = "OPTIONS")
    Empty rootOptions();
    
    /**
     * 
     * 
     * @param type 
     * @param page 
     * @return Empty
     */
    @com.amazonaws.mobileconnectors.apigateway.annotation.Operation(path = "/pets", method = "GET")
    Empty petsGet(
            @com.amazonaws.mobileconnectors.apigateway.annotation.Parameter(name = "type", location = "query")
            String type,
            @com.amazonaws.mobileconnectors.apigateway.annotation.Parameter(name = "page", location = "query")
            String page);
    
    /**
     * 
     * 
     * @return Empty
     */
    @com.amazonaws.mobileconnectors.apigateway.annotation.Operation(path = "/pets", method = "POST")
    Empty petsPost();
    
    /**
     * 
     * 
     * @return Empty
     */
    @com.amazonaws.mobileconnectors.apigateway.annotation.Operation(path = "/pets", method = "OPTIONS")
    Empty petsOptions();
    
    /**
     * 
     * 
     * @param petId 
     * @return Empty
     */
    @com.amazonaws.mobileconnectors.apigateway.annotation.Operation(path = "/pets/{petId}", method = "GET")
    Empty petsPetIdGet(
            @com.amazonaws.mobileconnectors.apigateway.annotation.Parameter(name = "petId", location = "path")
            String petId);
    
    /**
     * 
     * 
     * @param petId 
     * @return Empty
     */
    @com.amazonaws.mobileconnectors.apigateway.annotation.Operation(path = "/pets/{petId}", method = "DELETE")
    Empty petsPetIdDelete(
            @com.amazonaws.mobileconnectors.apigateway.annotation.Parameter(name = "petId", location = "path")
            String petId);
    
    /**
     * 
     * 
     * @return Empty
     */
    @com.amazonaws.mobileconnectors.apigateway.annotation.Operation(path = "/pets/{petId}", method = "OPTIONS")
    Empty petsPetIdOptions();
    
    /**
     * 
     * 
     * @param petId 
     * @return Empty
     */
    @com.amazonaws.mobileconnectors.apigateway.annotation.Operation(path = "/pets/{petId}/test", method = "DELETE")
    Empty petsPetIdTestDelete(
            @com.amazonaws.mobileconnectors.apigateway.annotation.Parameter(name = "petId", location = "path")
            String petId);
    
    /**
     * 
     * 
     * @return Empty
     */
    @com.amazonaws.mobileconnectors.apigateway.annotation.Operation(path = "/pets/{petId}/test", method = "OPTIONS")
    Empty petsPetIdTestOptions();
    
}

